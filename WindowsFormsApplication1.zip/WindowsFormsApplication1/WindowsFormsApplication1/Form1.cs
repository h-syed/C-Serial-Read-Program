﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;

namespace WindowsFormsApplication1
{
	public partial class Form1 : Form
	{

		private SerialPort Ser_port;
		private StreamWriter log;
		string solution_log;
		private string MainOutputDirectoryPathString = "..\\Output";
		private DateTime dateTimeObject;
		private string outputDirectoryPerLogPathString;
		bool stop;
		static Form1 frm;
		delegate void SetTextCallback(string display_string);

		public Form1()
		{
			InitializeComponent();
			frm = this;
		}

		private void BtnStartStop_Click(object sender, EventArgs e)
		{
			if (BtnStartStop.Text == "Start")
			{
				try
				{
					Ser_port = new SerialPort("COM26");
					Ser_port.BaudRate = 460800;
					Ser_port.Parity = Parity.None;
					Ser_port.StopBits = StopBits.One;
					Ser_port.DataBits = 8;
					Ser_port.Handshake = Handshake.None;
					Ser_port.RtsEnable = false;
					Ser_port.Open();
					BtnStartStop.Text = "Stop";
					stop = true;
					dateTimeObject = DateTime.Now;
					if (Directory.Exists(MainOutputDirectoryPathString) == false)
					{
						Directory.CreateDirectory(MainOutputDirectoryPathString);
					}

					outputDirectoryPerLogPathString = MainOutputDirectoryPathString + "\\" +
															String.Format("{0,4:D4}_{1,2:D2}_{2,2:D2}_{3,2:D2}_{4,2:D2}_{5,2:D2}",
																		dateTimeObject.Year,
																		dateTimeObject.Month,
																		dateTimeObject.Day,
																		dateTimeObject.Hour,
																		dateTimeObject.Minute,
																		dateTimeObject.Second
																		);

					//-- Create a directory where the output files are saved.
					if (Directory.Exists(outputDirectoryPerLogPathString) == false)
					{
						Directory.CreateDirectory(outputDirectoryPerLogPathString);
					}
					solution_log = outputDirectoryPerLogPathString + "\\" + "serial.log";
					log = new System.IO.StreamWriter(solution_log, true);
					Ser_port.DataReceived += new SerialDataReceivedEventHandler(sp_data_read);
				}
				catch
				{
					Console.WriteLine("error");
				}
			}
			else if (BtnStartStop.Text == "Stop")
			{
				stop = false;
				Ser_port.Close();
				BtnStartStop.Text = "Start";
				log.Close();
			}
		}

		void sp_data_read(object sender, SerialDataReceivedEventArgs e)
		{
			while (stop)
			{
				try
				{
					string reply = Ser_port.ReadTo("\n");
					reply += "\n";
					log.Write(reply);
					display_buffer(reply);
				}
				catch
				{
					Console.WriteLine("ended");
				}
			}
		}

		private void display_buffer(string string_)
		{
			if(this.textBox1.InvokeRequired)
			{ 
				SetTextCallback d = new SetTextCallback(display_buffer);
				this.Invoke(d, new object[] { string_ });
			}
			else
			{
				//frm.textBox1.Text = string_;
				frm.textBox1.AppendText(string_);
				
			}
		}

	}
}


